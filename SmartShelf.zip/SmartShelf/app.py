from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

# ---------- DB ----------
def init_db():
    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            quantity INTEGER NOT NULL
        )
    """)
    conn.commit()
    conn.close()

init_db()


# ---------- HOME ----------
@app.route('/')
def home():
    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("SELECT * FROM products")
    products = c.fetchall()
    conn.close()

    print("DEBUG:", products)   # check terminal

    return render_template("index.html", products=products)


# ---------- ADD ----------
@app.route('/add', methods=['POST'])
def add():
    name = request.form.get('name')
    quantity = request.form.get('quantity')

    # FORCE SAFE VALUES
    if name is None or name.strip() == "":
        return redirect('/')

    if quantity is None or quantity == "":
        quantity = 0

    quantity = int(quantity)

    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("INSERT INTO products (name, quantity) VALUES (?, ?)", (name, quantity))
    conn.commit()
    conn.close()

    return redirect('/')


# ---------- EDIT PAGE ----------
@app.route('/edit/<int:id>')
def edit(id):
    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("SELECT * FROM products WHERE id=?", (id,))
    product = c.fetchone()
    conn.close()

    return render_template("edit.html", product=product)


# ---------- UPDATE ----------
@app.route('/update/<int:id>', methods=['POST'])
def update(id):
    name = request.form.get('name')
    quantity = request.form.get('quantity')

    quantity = int(quantity)

    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("UPDATE products SET name=?, quantity=? WHERE id=?", (name, quantity, id))
    conn.commit()
    conn.close()

    return redirect('/')


# ---------- DELETE ----------
@app.route('/delete/<int:id>')
def delete(id):
    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute("DELETE FROM products WHERE id=?", (id,))
    conn.commit()
    conn.close()

    return redirect('/')


if __name__ == "__main__":
    app.run(debug=True)